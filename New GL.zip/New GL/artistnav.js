$(document).ready(function(){
   $(".genre").click(function(){
     $(this).hide();
   })
});
