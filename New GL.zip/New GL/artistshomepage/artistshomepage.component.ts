import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'artistshomepage',
  templateUrl: './artistshomepage.component.html',
  styleUrls: ['./artistshomepage.component.css']
})
export class ArtistsHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
