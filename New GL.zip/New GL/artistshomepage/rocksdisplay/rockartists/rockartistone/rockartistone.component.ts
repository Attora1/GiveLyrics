import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rockartistone',
  templateUrl: './rockartistone.component.html',
  styleUrls: ['./rockartistone.component.css']
})
export class RockArtistOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
