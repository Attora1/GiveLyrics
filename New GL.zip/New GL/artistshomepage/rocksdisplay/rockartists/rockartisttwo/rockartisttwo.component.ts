import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rockartisttwo',
  templateUrl: './rockartisttwo.component.html',
  styleUrls: ['./rockartisttwo.component.css']
})
export class RockArtistTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
