import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rockartists',
  templateUrl: './rockartists.component.html',
  styleUrls: ['./rockartists.component.css']
})
export class RockArtistsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
