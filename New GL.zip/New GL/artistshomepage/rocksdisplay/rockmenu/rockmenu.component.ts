import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rockmenu',
  templateUrl: './rockmenu.component.html',
  styleUrls: ['./rockmenu.component.css']
})
export class RockMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
