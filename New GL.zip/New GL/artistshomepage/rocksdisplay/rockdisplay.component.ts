import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rockdisplay',
  templateUrl: './rockdisplay.component.html',
  styleUrls: ['./rockdisplay.component.css']
})
export class RockDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
