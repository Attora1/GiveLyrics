import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hiphopmenu',
  templateUrl: './hiphopmenu.component.html',
  styleUrls: ['./hiphopmenu.component.css']
})
export class HipHopMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
