import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hiphopdisplay',
  templateUrl: './hiphopdisplay.component.html',
  styleUrls: ['./hiphopdisplay.component.css']
})
export class HipHopDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
