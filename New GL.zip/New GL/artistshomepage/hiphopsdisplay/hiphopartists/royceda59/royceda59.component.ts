import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'royceda59',
  templateUrl: './royceda59.component.html',
  styleUrls: ['./royceda59.component.css']
})
export class Royceda59Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
