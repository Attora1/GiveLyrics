import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'icewearvezzo',
  templateUrl: './icewearvezzo.component.html',
  styleUrls: ['./icewearvezzo.component.css']
})
export class IcewearvezzoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
