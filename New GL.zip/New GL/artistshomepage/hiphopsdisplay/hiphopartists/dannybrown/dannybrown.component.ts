import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dannybrown',
  templateUrl: './dannybrown.component.html',
  styleUrls: ['./dannybrown.component.css']
})
export class DannyBrownTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
