import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'apaak',
  templateUrl: './apaak.component.html',
  styleUrls: ['./apaak.component.css']
})
export class APaakComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
