import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hiphopartists',
  templateUrl: './hiphopartists.component.html',
  styleUrls: ['./hiphopartists.component.css']
})
export class HipHopArtistsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
