import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rbmenu',
  templateUrl: './rbmenu.component.html',
  styleUrls: ['./rbmenu.component.css']
})
export class RBMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
