import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-monicablaire',
  templateUrl: './monicablaire.component.html',
  styleUrls: ['./monicablaire.component.css']
})
export class MonicablaireComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
