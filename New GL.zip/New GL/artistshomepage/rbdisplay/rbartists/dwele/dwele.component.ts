import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dwele',
  templateUrl: './dwele.component.html',
  styleUrls: ['./dwele.component.css']
})
export class DweleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
