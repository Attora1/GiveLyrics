import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rbartists',
  templateUrl: './rbartists.component.html',
  styleUrls: ['./rbartists.component.css']
})
export class RBArtistsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
