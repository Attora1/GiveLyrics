import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rbdisplay',
  templateUrl: './rbdisplay.component.html',
  styleUrls: ['./rbdisplay.component.css']
})
export class RBDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
