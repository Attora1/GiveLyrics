import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'otherdisplay',
  templateUrl: './otherdisplay.component.html',
  styleUrls: ['./otherdisplay.component.css']
})
export class OtherDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
