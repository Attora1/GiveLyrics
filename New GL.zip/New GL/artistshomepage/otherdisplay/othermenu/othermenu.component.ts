import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'othermenu',
  templateUrl: './othermenu.component.html',
  styleUrls: ['./othermenu.component.css']
})
export class OtherMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
