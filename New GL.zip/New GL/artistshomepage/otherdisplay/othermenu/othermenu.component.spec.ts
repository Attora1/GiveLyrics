import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherMenuComponent } from './othermenu.component';

describe('OtherMenuComponent', () => {
  let component: OtherMenuComponent;
  let fixture: ComponentFixture<OtherMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
