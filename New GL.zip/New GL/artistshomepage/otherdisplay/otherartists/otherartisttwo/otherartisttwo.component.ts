import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'otherartisttwo',
  templateUrl: './otherartisttwo.component.html',
  styleUrls: ['./otherartisttwo.component.css']
})
export class OtherArtistsTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
