import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'otherartists',
  templateUrl: './otherartists.component.html',
  styleUrls: ['./otherartists.component.css']
})
export class OtherArtistsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
