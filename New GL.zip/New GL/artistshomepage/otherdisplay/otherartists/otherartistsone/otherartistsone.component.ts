import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'otherartistsone',
  templateUrl: './otherartistsone.component.html',
  styleUrls: ['./otherartistsone.component.css']
})
export class OtherArtistsOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
