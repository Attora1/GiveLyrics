import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'countrymenu',
  templateUrl: './countrymenu.component.html',
  styleUrls: ['./countrymenu.component.css']
})
export class CountryMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
