import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'countrydisplay',
  templateUrl: './countrydisplay.component.html',
  styleUrls: ['./countrydisplay.component.css']
})
export class CountryDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
