import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'countryartiststwo',
  templateUrl: './countryartiststwo.component.html',
  styleUrls: ['./countryartiststwo.component.css']
})
export class CountryArtistsTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
