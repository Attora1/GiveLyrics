import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'countryartists',
  templateUrl: './countryartists.component.html',
  styleUrls: ['./countryartists.component.css']
})
export class CountryArtistsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
