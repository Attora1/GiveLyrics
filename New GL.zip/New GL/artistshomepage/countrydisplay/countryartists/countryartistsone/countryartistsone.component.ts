import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'countryartistsone',
  templateUrl: './countryartistsone.component.html',
  styleUrls: ['./countryartistsone.component.css']
})
export class CountryArtistsOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
