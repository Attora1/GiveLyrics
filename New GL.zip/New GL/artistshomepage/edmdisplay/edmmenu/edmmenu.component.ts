import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'edmmenu',
  templateUrl: './edmmenu.component.html',
  styleUrls: ['./edmmenu.component.css']
})
export class EDMMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
