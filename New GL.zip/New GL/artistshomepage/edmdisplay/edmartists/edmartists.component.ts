import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'edmartists',
  templateUrl: './edmartists.component.html',
  styleUrls: ['./edmartists.component.css']
})
export class EDMArtistsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
