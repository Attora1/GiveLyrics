import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'edmartisttwo',
  templateUrl: './edmartisttwo.component.html',
  styleUrls: ['./edmartisttwo.component.css']
})
export class EDMArtistTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
