import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'edmartistone',
  templateUrl: './edmartistone.component.html',
  styleUrls: ['./edmartistone.component.css']
})
export class EDMArtistOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
