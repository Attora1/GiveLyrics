import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'edmdisplay',
  templateUrl: './edmdisplay.component.html',
  styleUrls: ['./edmdisplay.component.css']
})
export class EDMDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
