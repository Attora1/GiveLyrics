import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'artistnav',
  templateUrl: './artistnav.component.html',
  styleUrls: ['./artistnav.component.css']
})


export class ArtistnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
